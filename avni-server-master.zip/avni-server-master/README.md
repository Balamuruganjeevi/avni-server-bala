# avni-server


### Developer machine setup
See instructions available at https://avni.readme.io/docs/developer-environment-setup-ubuntu#server-side-components


## Build Status

[![CircleCI](https://dl.circleci.com/status-badge/img/gh/avniproject/avni-server/tree/master.svg?style=svg)](https://dl.circleci.com/status-badge/redirect/gh/avniproject/avni-server/tree/master)
