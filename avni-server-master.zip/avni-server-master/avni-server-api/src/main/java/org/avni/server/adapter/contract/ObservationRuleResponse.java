package org.avni.server.adapter.contract;

public class ObservationRuleResponse {

}
