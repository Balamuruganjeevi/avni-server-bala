package org.avni.server.domain.enums.ruleFailure;

public enum AppType {
    Android, Web
}