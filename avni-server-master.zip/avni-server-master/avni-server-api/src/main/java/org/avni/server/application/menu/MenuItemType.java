package org.avni.server.application.menu;

public enum MenuItemType {
    Link,
    Document
}
