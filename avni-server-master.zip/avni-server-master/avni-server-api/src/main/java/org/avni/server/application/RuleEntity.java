package org.avni.server.application;

public enum RuleEntity {
    ProgramEncounter, ProgramEnrolment, Encounter, IndividualProfile
}
