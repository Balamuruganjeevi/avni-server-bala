package org.avni.server.application;

public enum SubjectTypeSettingKey {
    displayRegistrationDetails, displayPlannedEncounters
}
