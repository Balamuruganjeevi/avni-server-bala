package org.avni.server.dao.individualRelationship;

import org.avni.server.dao.AvniCrudRepository;
import org.avni.server.domain.RuleFailureLog;

public interface RuleFailureLogRepository extends AvniCrudRepository<RuleFailureLog, Long> {
}
