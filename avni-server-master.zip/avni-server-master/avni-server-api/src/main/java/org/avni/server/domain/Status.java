package org.avni.server.domain;

public enum Status {
    open, closed
}
