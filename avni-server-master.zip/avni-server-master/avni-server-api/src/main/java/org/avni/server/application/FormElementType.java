package org.avni.server.application;

public enum FormElementType {
    SingleSelect, MultiSelect
}
