package org.avni.server.domain.metadata;

public enum OrganisationCategory {
    Production, UAT, Prototype, Temporary
}
