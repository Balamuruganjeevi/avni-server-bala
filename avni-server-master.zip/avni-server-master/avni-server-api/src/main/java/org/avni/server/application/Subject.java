package org.avni.server.application;

public enum Subject {
    Group, Household, Individual, Person, User
}
