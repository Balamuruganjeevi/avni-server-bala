package org.avni.server.application.projections;

public interface BaseProjection {
    Long getId();
    String getUuid();
}
