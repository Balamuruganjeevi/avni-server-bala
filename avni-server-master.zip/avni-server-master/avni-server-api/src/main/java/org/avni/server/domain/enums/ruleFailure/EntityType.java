package org.avni.server.domain.enums.ruleFailure;

public enum EntityType {
    Individual, ProgramEnrolment, ProgramEncounter, Encounter, WorkList, Checklist, ReportCard, ChecklistItem;
}
