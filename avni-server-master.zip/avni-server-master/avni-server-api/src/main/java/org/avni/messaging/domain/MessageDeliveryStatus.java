package org.avni.messaging.domain;

public enum MessageDeliveryStatus {
    NotSent,
    NotSentNoPhoneNumberInAvni,
    PartiallySent,
    Sent,
    Failed
}
