package org.avni.server.domain.identifier;

public enum IdentifierGeneratorType {
    userPoolBasedIdentifierGenerator,
    userBasedIdentifierGenerator
}
