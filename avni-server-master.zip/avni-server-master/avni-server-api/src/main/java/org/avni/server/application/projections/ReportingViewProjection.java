package org.avni.server.application.projections;

public interface ReportingViewProjection {
    String getViewname();
    String getDefinition();
}
