package org.avni.server.domain.extenalSystem;


public enum SystemName {
    Exotel,
    Glific
}
