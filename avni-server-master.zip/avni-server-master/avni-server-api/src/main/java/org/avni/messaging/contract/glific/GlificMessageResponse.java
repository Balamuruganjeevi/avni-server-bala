package org.avni.messaging.contract.glific;

public class GlificMessageResponse {
}
