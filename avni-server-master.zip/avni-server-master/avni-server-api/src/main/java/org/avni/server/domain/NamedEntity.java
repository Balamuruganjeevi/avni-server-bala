package org.avni.server.domain;

public interface NamedEntity {
    String getName();
    Long getId();
}
