package org.avni.server.domain;

public enum RuleEntityType {
    EncounterType,
    Program
}
