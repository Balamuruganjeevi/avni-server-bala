package org.avni.server.builder;

public class FormBuilderException extends Exception {
    public FormBuilderException(String message) {
        super(message);
    }
}
