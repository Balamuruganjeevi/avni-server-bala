package org.avni.messaging.domain.exception;

public class GlificException extends Exception {
    public GlificException(String message) {
        super(message);
    }
}
