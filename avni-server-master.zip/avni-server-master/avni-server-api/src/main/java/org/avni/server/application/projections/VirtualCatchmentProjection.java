package org.avni.server.application.projections;

public interface VirtualCatchmentProjection {
    Long getId();
    Long getAddresslevel_id();
    Long getCatchment_id();
    Long getType_id();
}
