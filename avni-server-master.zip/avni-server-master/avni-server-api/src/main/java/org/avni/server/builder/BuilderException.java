package org.avni.server.builder;

public class BuilderException extends RuntimeException {
    public BuilderException(String message) {
        super(message);
    }
}
