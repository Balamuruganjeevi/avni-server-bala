package org.avni.server.config;

public enum IdpType {
    none,
    keycloak,
    cognito,
    both;
}
