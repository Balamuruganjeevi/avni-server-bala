package org.avni.server.exporter;

public interface ItemReaderCleaner {
    void clean();
}
