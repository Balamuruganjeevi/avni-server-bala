package org.avni.server.domain.reporting;

public class Names {
    public static final String DecisionConceptMapName = "concepts_decisions";
}
