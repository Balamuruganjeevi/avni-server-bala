package org.avni.messaging.contract.glific;

public class GlificOptinContactWithErrorsResponse {

    private GlificContactResponse contact;

    public GlificContactResponse getContact() {
        return contact;
    }

    public void setContact(GlificContactResponse contact) {
        this.contact = contact;
    }
}
