package org.avni.server.application.menu;

public enum MenuItemGroup {
    Functionality, Sync, User, Support
}
