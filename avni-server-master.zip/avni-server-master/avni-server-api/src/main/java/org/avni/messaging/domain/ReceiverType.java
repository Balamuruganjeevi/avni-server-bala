package org.avni.messaging.domain;

public enum ReceiverType {
    User,
    Subject,
    Group
}
