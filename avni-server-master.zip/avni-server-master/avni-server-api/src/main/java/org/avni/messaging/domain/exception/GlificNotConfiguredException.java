package org.avni.messaging.domain.exception;

public class GlificNotConfiguredException extends Exception {
    public GlificNotConfiguredException(String message) {
        super(message);
    }
}
