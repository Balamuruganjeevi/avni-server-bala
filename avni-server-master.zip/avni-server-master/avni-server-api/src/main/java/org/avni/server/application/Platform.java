package org.avni.server.application;

public enum Platform {
    Android,
    Web
}
