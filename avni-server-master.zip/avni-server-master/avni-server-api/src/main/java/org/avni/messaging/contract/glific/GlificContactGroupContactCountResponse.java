package org.avni.messaging.contract.glific;

public class GlificContactGroupContactCountResponse {
    private int countContacts;

    public int getCountContacts() {
        return countContacts;
    }

    public void setCountContacts(int countContacts) {
        this.countContacts = countContacts;
    }
}
