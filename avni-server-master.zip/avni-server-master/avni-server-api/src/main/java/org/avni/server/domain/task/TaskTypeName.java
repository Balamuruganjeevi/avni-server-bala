package org.avni.server.domain.task;

public enum TaskTypeName {
    Call, OpenSubject
}
