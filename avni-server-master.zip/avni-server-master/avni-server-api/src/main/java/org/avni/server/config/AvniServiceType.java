package org.avni.server.config;

public enum AvniServiceType {
    ETL
}
