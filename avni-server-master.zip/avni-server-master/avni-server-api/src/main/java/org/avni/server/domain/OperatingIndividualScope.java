package org.avni.server.domain;

public enum OperatingIndividualScope {
    ByCatchment,
    None
}
