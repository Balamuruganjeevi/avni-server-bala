---
name: Story
about: Template for avni-server stories
title: ''
labels: ''
assignees: ''

---

### Motivation

### Acceptance Criteria

### Request

### Happy path Response

### Exception path Response

### Tech Approach

### Visual Design
